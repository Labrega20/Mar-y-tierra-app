// Backend server for Mar y Tierra
const express = require('express');
const app = express();
const PORT = 3000;
app.use(express.json());

// Routes
app.get('/', (req, res) => res.send('Mar y Tierra Backend'));

app.listen(PORT, () => console.log(`Server running on port ${PORT}`));