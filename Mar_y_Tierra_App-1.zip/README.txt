
Mar y Tierra App - Código fuente

Estructura del proyecto:
1. frontend/
   - src/index.html: Página principal de la app.
   - src/styles.css: Estilos básicos para la app.
   - src/app.js: Lógica principal del frontend.
2. backend/
   - server.js: Configuración del servidor backend.
   - routes/: Carpeta para las rutas API.
   - models/: Carpeta para los modelos de la base de datos.
   - controllers/: Carpeta para la lógica de negocio.

Pasos para usar el código:
1. Frontend:
   - Ve a la carpeta "frontend/src".
   - Usa un servidor local como "Live Server" o "parcel" para probar el frontend.

2. Backend:
   - Instala Node.js y npm.
   - Corre `npm install` para instalar dependencias.
   - Corre `node server.js` para iniciar el servidor.

Puedes subir este proyecto a GitHub o desplegarlo en Firebase/Heroku.
