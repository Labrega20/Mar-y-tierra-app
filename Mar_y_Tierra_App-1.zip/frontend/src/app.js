// JavaScript for the Mar y Tierra app
console.log('App started');